from .cifar10 import Cifar10
from .cifar100 import Cifar100
from .svhn import SVHN